# CodeIgniter Português do Brasil

Tradução das strings do CodeIgniter para português do Brasil.

## Uso

Para usar basta adicionar o diretório `portuguese-br` em `application/language`
e alterar a configuração `$config['language']` para `portuguese-br` em
`application/config/config.php`.
